package com.cm.centerApp.utill;

public class Admin {
	public static final String ADMIN_ID = "admin";
	public static final String ADMIN_PASSWD = "1234";
}
